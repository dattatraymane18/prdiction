# Cricket-Player-Performance-Prediction

Introduction
A cricket match prediction enhances and develops interest for a viewer watching a cricket match. Apart from having pleasure while watching a game, it also assists individuals in creating their Dream XI squad. The model predicts an individual player's performance by taking into account the elements related to the performance.

Cricket player performance prediction
Cricket player performance prediction is a model that predicts the amount of runs scored by a batter with a specific number of balls encountered and inside a specific over. It comprises of a dataset of players' prior performance records. The model basically assesses that specific player's historical performance combined with the other factors and produces predicted value.

To predict, it requires specific information such as the player's name and the name of the opposing team, followed by the number of balls that player may encounter within a specified time frame (i.e. 50 or inside).

Regression Method (Supervised Learning), in which data is tested and trained before being utilised for prediction. Unlike Unsupervised, here the data has a label and is taught based on it. They are classified as dependent and independent variables, with dependent being the label that we are attempting to predict and independent variables being the other attributes. We can apply several regressors and select the best accurate regression to predict the correct outcome.
